(function() {
  /* Exploring prototype chains  */
  const a = {x: 1, y: 2};
  const b = Object.create(a);

  function C () {
    this.x = 1
    this.y = 2
  };
  const c = new C();

  class D {
    constructor () {
      this.x = 1
      this.y = 2
    }
  };
  const d = new D();

  console.log(a.isPrototypeOf(b)); // true
  console.log(C.prototype.isPrototypeOf(c)); // true
  console.log(Object.prototype.isPrototypeOf(c)); // true
  console.log(D.prototype.isPrototypeOf(d)); // true
  console.log(Object.prototype.isPrototypeOf(d)); // true
  console.log(a.isPrototypeOf(c)); // false
  console.log(Object.prototype.isPrototypeOf(a)); // true

  console.log('=======================REASSIGNING PROTOTYPES================');
  /* reassigning the prototype of an object  */

  const xGetter = {getX: function () { return this.x; }}
  Object.setPrototypeOf(a, xGetter);

  /* reassigning prototype of a Function Constructor */
  C.prototype = a;
  const c1 = new C();
  console.log(xGetter.isPrototypeOf(c)); // false
  console.log(xGetter.isPrototypeOf(c1)); // true
  console.log(c1.getX()); // false
  /*
  classes use the extends keyword and only extend other classes
  Class A [extends Class<?>]
  */

  console.log('===============EXTENDING OBJECT PROTOTYPE===================');
  /* Extending prototypes */
  console.log('toString before extension');
  console.log(a.toString()); // "[object Object]"
  Object.prototype.toString = function() {return JSON.stringify(this);};
  console.log('toString after extension');
  console.log(a.toString()); // "{"x":1,"y":2}
})();