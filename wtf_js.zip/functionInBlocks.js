/* point 1 in the specification */

(function g(){
  function f() { console.log('f3')}
  {
    function f() { console.log('f1')}
    function f() { console.log('f2')}
  }
  function f() { console.log('f3')}
  f(); //f2
})();

/* point 2 in the specification */

(function(){
  {
    function f() { console.log('f1')}
    function f() { console.log('f2')}
  }
  function f() { console.log('f3')}
  h();

  function h() {
    f(); // f2
  }
})();

(function(){
  h(); // f3
  {
    function f() { console.log('f1')}
    function f() { console.log('f2')}
  }
  function f() { console.log('f3')}


  function h() {
    f();
  }
})();

/* point 3 of the specification */

(function(){
  {
    function f() { console.log('f1')}
    function f() { console.log('f2')}
  }

  {
    f();
  }
})();