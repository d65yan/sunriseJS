(function() {
  /* defining parameters*/
  const a = 1;
  const b = '1';
  const c = new Number(1);
  const d = new Number(1);
  const t = true;
  const f = false;
  const z = 0;


  console.log('/* Abstract Equality */');

  console.log('a == b == c ', a == b == c);  // true
  console.log('c == d ', c == d); 	    // false
  console.log('a == t ', a == t);	    // true
  console.log('z == t	', z == t);    // false
  console.log('z == f ', z == f);	    // true
  console.log('t == f	', t == f);	    // false

  console.log('/* strict Equality */');

  console.log('a === b === c ', a === b === c);  // false
  console.log('c === d ', c === d); 	    // false
  console.log('a === t ', a === t); 	    // false
  console.log('z === t ',z === t);	    // false
  console.log('z === f ',  z === f); 	    // false
  console.log('t === f ', t === f);    // false
  console.log('a === 1 ', a === 1);         // true
})();

