var vG = 'variabes in Global';
(
  function() {
    function a () {
      const vA = 'variabes in A';

      function b () {
        const vB = 'variabes in B';

        function c () {
          const vC = 'variabes in C';

          function d () {
            console.log('vC == ', vC);
            console.log('vB == ', vB);
            console.log('vA == ', vA);
            console.log('vG == ', vG)
            return d;
          }
          return d();
        }
        return c();
      }
      return b();
    }

    d = a();
    debugger;
  }
)();