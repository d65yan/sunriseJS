/* let and const vs var scopes */

/* uncomment lines to discover the variable scope */

(function () {
  console.log('========', a)
  // console.log('-----------', b);
  // console.log('+++++++', c);
  fd()
  // fe();
  // vLambda();

  {
    console.log('=================IN THE BLOCK==============')
    // cfe();
    // cLambda();
    var a = 1
    const b = 2

    const cfe = function () { console.log('I am `cfe`') }
    const cLambda = () => console.log('I am `cLambda`')
    var vlambda =  () => console.log('I am `vLambda`');
    console.log('========', a)
    console.log('-----------', b)
    // console.log('+++++++', c);

    cfe()
    cLambda()
  }
  console.log('=================OUT OF THE BLOCK==============')
  let c = 3
  console.log('========', a)
  // cfe();
  // cLambda();
  console.log('+++++++', c)
  //fe()

  function fd () { console.log('I am `fd`') }
  var fe = function () { console.log('I am `fe`') }
  fd()
  vlambda();
})();

(
  /* try/catch to create block scope */
  function () {
    try {
      throw(() => console.log('this is crazy'))
    } catch (catchFn) {
      catchFn();
    }
    //catchFn();
  }
)();
