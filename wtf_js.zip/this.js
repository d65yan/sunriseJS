(function () {
  // implicit binding to a(lexical context) as execution context
  const a = { name: 'Object A', greet: function greet () { console.log(`Hello, my name is ${this.name}`) } };
  a.greet()     // Hello, my name is Object A
  const b = { name: 'Object B' };
// implicit binding to b as execution context
  b.greet = a.greet;
  b.greet()     // Hello, my name is Object B
  const c = { name: 'Object C' };
// explicit binding to c as execution context
  b.greet.call(c);     // Hello, my name is Object C
  b.greet.apply(c);   // Hello, my name is Object C
  b.greet.bind(c);
  const d = b.greet.bind(c)
// explicitly bound functions don't change the execution context by themselves
  d()       // Hello, my name is Object C
// implicit binding to global as execution context
  const e = b.greet;
  e()      // Hello, my name is
  window.name = 'WINDOW';
  e()      // Hello, my name is WINDOW

  // explicitly bound to current execution context
  const modernA = { name: 'Object A', greet: () => `Hello, my name is ${this.name}`};
  modernA.greet()  // "Hello, my name is WINDOW"
})();
