function greet (name, time) {
  console.log(`hello ${a}, good ${time}`)
}

function greet (c) {
  console.log('hi')
}

greet('user', 'morning') // hi

/* simple sum of variable arguments */

function sumArguments () {
  let sum = 0
  for (let i = 0; i < arguments.length; i++) {
    sum += arguments[i]
  }
  return sum
}

/* Implementing currying */

function sum4Arguments () {
  let sum = 0
  let totalArguments = arguments.length
  let argumentsToSum = arguments[0]

  if (totalArguments >= 1 && totalArguments >= (argumentsToSum + 1)) {
    for (let i = 1; i < (arguments[0] + 1); i++) {
      sum += arguments[i]
    }
    return sum
  }

  const args = Array.prototype.slice.call(arguments)
  return function () {
    const newArgs = args.concat(Array.prototype.slice.call(arguments))
    return sum4Arguments.apply(this, newArgs)
  }
}

/* Implementing currying es6 */

function sumArguments (argumentsToSum, ...args) {
  if (args.length >= argumentsToSum) {
    return args.slice(0, argumentsToSum)
      .reduce((sum, number) => sum + number, 0);
  }
  return (...tempArgs) => (sumArguments.apply(this, [argumentsToSum, ...args, ...tempArgs]))
}

